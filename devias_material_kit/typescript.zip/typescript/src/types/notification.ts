export interface Notification {
  id: string;
  title: string;
  description: string;
  type: string;
  createdAt: number;
}